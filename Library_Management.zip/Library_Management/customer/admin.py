from django.contrib import admin
from customer.models import students_profile
# Register your models here.
admin.site.register(students_profile)