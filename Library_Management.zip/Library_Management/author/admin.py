from django.contrib import admin
from author.models import Authors_profile
# Register your models here.
admin.site.register(Authors_profile)
